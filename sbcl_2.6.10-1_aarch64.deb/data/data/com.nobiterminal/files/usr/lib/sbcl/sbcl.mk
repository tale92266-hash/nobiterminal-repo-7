CC=aarch64-linux-android-clang
LD=ld
CFLAGS= -fstack-protector-strong -Oz -g -Wall -Wundef -Wsign-compare -Wpointer-arith -O3 -std=gnu99
ASFLAGS= -fstack-protector-strong -Oz -g -Wall -Wundef -Wsign-compare -Wpointer-arith -O3 -std=gnu99
LINKFLAGS=-L/data/data/com.nobiterminal/files/usr/lib -Wl,-rpath=/data/data/com.nobiterminal/files/usr/lib -Wl,--enable-new-dtags -Wl,--as-needed -Wl,-z,relro,-z,now -g -Wl,--export-dynamic
LDFLAGS=
__LDFLAGS__=
LIBS=-ldl -Wl,-no-as-needed -lpthread -lzstd  -lm
