#pragma once

#define CODON_VERSION       "0.20.6"
#define CODON_VERSION_MAJOR 0
#define CODON_VERSION_MINOR 20
#define CODON_VERSION_PATCH 6
