require "c/io"
require "c/consoleapi"
require "c/consoleapi2"
require "c/ntifs"
require "c/winnls"
require "crystal/system/win32/iocp"
require "crystal/system/thread"

module Crystal::System::FileDescriptor
  # Platform-specific type to represent a file descriptor handle to the operating
  # system.
  # NOTE: this should really be `LibC::HANDLE`, here it is an integer type of
  # the same size so that `IO::FileDescriptor#fd` continues to return an `Int`
  alias Handle = ::LibC::UIntPtrT

  STDIN_HANDLE  = LibC.GetStdHandle(LibC::STD_INPUT_HANDLE).address
  STDOUT_HANDLE = LibC.GetStdHandle(LibC::STD_OUTPUT_HANDLE).address
  STDERR_HANDLE = LibC.GetStdHandle(LibC::STD_ERROR_HANDLE).address

  @system_blocking = true

  def system_append?
    false
  end

  private def system_read(slice : Bytes) : Int32
    handle = windows_handle
    if ConsoleUtils.console?(handle)
      ConsoleUtils.read(handle, slice)
    elsif system_blocking?
      read_blocking(handle, slice)
    else
      event_loop.read(self, slice)
    end
  end

  private def read_blocking(handle, slice)
    ret = LibC.ReadFile(handle, slice, slice.size, out bytes_read, nil)
    if ret.zero?
      case error = WinError.value
      when .error_access_denied?
        raise IO::Error.new "File not open for reading", target: self
      when .error_broken_pipe?
        return 0_i32
      else
        raise IO::Error.from_os_error("Error reading file", error, target: self)
      end
    end
    bytes_read.to_i32
  end

  def system_pread(slice : Bytes, offset : Int64) : Int32
    if system_blocking?
      pread_blocking(slice, offset)
    else
      event_loop.pread(self, slice, offset)
    end
  end

  private def pread_blocking(slice, offset)
    overlapped = LibC::OVERLAPPED.new
    overlapped.union.offset.offset = LibC::DWORD.new!(offset)
    overlapped.union.offset.offsetHigh = LibC::DWORD.new!(offset >> 32)

    if LibC.ReadFile(windows_handle, slice, slice.size, out bytes_read, pointerof(overlapped)) == 0
      error = WinError.value
      return 0_i32 if error == WinError::ERROR_HANDLE_EOF
      raise IO::Error.from_os_error "Error reading file", error, target: self
    end
    bytes_read.to_i32
  end

  private def system_write(slice : Bytes) : Int32
    handle = windows_handle
    if system_blocking?
      write_blocking(handle, slice).to_i32
    else
      event_loop.write(self, slice)
    end
  end

  private def write_blocking(handle, slice, pos = nil)
    overlapped = LibC::OVERLAPPED.new
    if pos
      overlapped.union.offset.offset = LibC::DWORD.new!(pos)
      overlapped.union.offset.offsetHigh = LibC::DWORD.new!(pos >> 32)
      overlapped_ptr = pointerof(overlapped)
    else
      overlapped_ptr = Pointer(LibC::OVERLAPPED).null
    end

    ret = LibC.WriteFile(handle, slice, slice.size, out bytes_written, overlapped_ptr)
    if ret.zero?
      case error = WinError.value
      when .error_access_denied?
        raise IO::Error.new "File not open for writing", target: self
      else
        raise IO::Error.from_os_error("Error writing file", error, target: self)
      end
    end
    bytes_written
  end

  def emulated_blocking? : Bool?
    # reading from STDIN is done via a separate thread (see
    # `ConsoleUtils.read_console` below)
    handle = windows_handle
    if LibC.GetConsoleMode(handle, out _) != 0
      if handle == LibC.GetStdHandle(LibC::STD_INPUT_HANDLE)
        return false
      end
    end
  end

  # :nodoc:
  def system_blocking?
    @system_blocking
  end

  def self.get_blocking(fd : Handle)
    raise NotImplementedError.new("Cannot query the blocking mode of an `IO::FileDescriptor`")
  end

  def self.set_blocking(fd : Handle, value : Bool)
    raise NotImplementedError.new("Cannot change the blocking mode of an `IO::FileDescriptor` after creation")
  end

  private def system_blocking=(blocking)
    unless blocking == system_blocking?
      raise IO::Error.new("Cannot reconfigure `IO::FileDescriptor#blocking` after creation")
    end
  end

  protected def system_blocking_init(blocking : Bool?)
    if blocking.nil?
      # there are no official API to know whether a handle has been opened with
      # the OVERLAPPED flag, but the following call is supposed to leak the
      # information: if neither of the SYNCHRONOUS_IO flags are set then the
      # OVERLAPPED flag has been set
      info = LibC::FILE_MODE_INFORMATION.new
      status = LibC.NtQueryInformationFile(windows_handle, out _, pointerof(info), sizeof(LibC::FILE_MODE_INFORMATION), LibC::FILE_INFORMATION_CLASS::FileModeInformation)
      blocking = status != LibC::STATUS_SUCCESS || (info.mode & (LibC::FILE_SYNCHRONOUS_IO_ALERT | LibC::FILE_SYNCHRONOUS_IO_NONALERT)) != 0
    end
    @system_blocking = blocking
    Crystal::EventLoop.current.create_completion_port(windows_handle) unless blocking
  end

  private def system_close_on_exec?
    false
  end

  private def system_close_on_exec=(close_on_exec)
    raise NotImplementedError.new("Crystal::System::FileDescriptor#system_close_on_exec=") if close_on_exec
    false
  end

  private def system_closed? : Bool
    file_type = LibC.GetFileType(windows_handle)

    if file_type == LibC::FILE_TYPE_UNKNOWN
      case error = WinError.value
      when .error_invalid_handle?
        return true
      else
        raise IO::Error.from_os_error("Unable to get info", error, target: self)
      end
    else
      false
    end
  end

  def self.fcntl(fd, cmd, arg = 0)
    raise NotImplementedError.new "Crystal::System::FileDescriptor.fcntl"
  end

  private def system_fcntl(cmd, arg = 0)
    raise NotImplementedError.new "Crystal::System::FileDescriptor#system_fcntl"
  end

  protected def windows_handle
    LibC::HANDLE.new(fd)
  end

  def self.system_info(handle, file_type = nil)
    unless file_type
      file_type = LibC.GetFileType(handle)

      if file_type == LibC::FILE_TYPE_UNKNOWN
        error = WinError.value
        raise IO::Error.from_os_error("Unable to get info", error, target: self) unless error == WinError::ERROR_SUCCESS
      end
    end

    if file_type == LibC::FILE_TYPE_DISK
      if LibC.GetFileInformationByHandle(handle, out file_info) == 0
        raise IO::Error.from_winerror("Unable to get info")
      end

      ::File::Info.new(file_info, file_type)
    else
      ::File::Info.new(file_type)
    end
  end

  private def system_info
    FileDescriptor.system_info windows_handle
  end

  def system_seek(offset, whence : IO::Seek) : Nil
    if LibC.SetFilePointerEx(windows_handle, offset, nil, whence) == 0
      raise IO::Error.from_winerror("Unable to seek", target: self)
    end
  end

  private def system_pos
    if LibC.SetFilePointerEx(windows_handle, 0, out pos, IO::Seek::Current) == 0
      raise IO::Error.from_winerror("Unable to tell", target: self)
    end
    pos
  end

  private def system_tty?
    LibC.GetConsoleMode(windows_handle, out _) != 0
  end

  private def system_reopen(other : IO::FileDescriptor)
    cur_proc = LibC.GetCurrentProcess
    if LibC.DuplicateHandle(cur_proc, other.windows_handle, cur_proc, out new_handle, 0, true, LibC::DUPLICATE_SAME_ACCESS) == 0
      raise IO::Error.from_winerror("Could not reopen file descriptor")
    end
    @volatile_fd.set(new_handle.address)

    # Mark the handle open, since we had to have dup'd a live handle.
    @closed = false
  end

  def file_descriptor_close(&)
    # Clear the @volatile_fd before actually closing it in order to
    # reduce the chance of reading an outdated handle value
    handle = LibC::HANDLE.new(@volatile_fd.swap(LibC::INVALID_HANDLE_VALUE.address))

    if LibC.CloseHandle(handle) == 0
      yield
    end
  end

  def file_descriptor_close
    file_descriptor_close do
      raise IO::Error.from_winerror("Error closing file", target: self)
    end
  end

  private def system_lock(blocking : Bool, exclusive : Bool) : Nil
    flags = exclusive ? LibC::LOCKFILE_EXCLUSIVE_LOCK : 0_u32

    if blocking && !system_blocking?
      IOCP.simple_overlapped_operation(Crystal::EventLoop.current.iocp_handle, self, "LockFileEx") do |operation|
        LibC.LockFileEx(windows_handle, flags, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, operation)
      end
    else
      overlapped = LibC::OVERLAPPED.new

      # 1st attempt (always non-blocking)
      ret = LibC.LockFileEx(windows_handle, flags | LibC::LOCKFILE_FAIL_IMMEDIATELY, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, pointerof(overlapped))
      error = WinError.value

      while true
        return unless ret == 0

        if error == WinError::ERROR_LOCK_VIOLATION
          raise IO::Error.from_os_error("Error applying file lock: file is already locked", error, target: self) unless blocking
        else
          raise IO::Error.from_os_error("Error applying file lock", error, target: self)
        end

        ret, error =
          {% if !flag?(:without_mt) && !flag?(:preview_mt) || flag?(:execution_context) %}
            ::Fiber.syscall do
              {LibC.LockFileEx(windows_handle, flags, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, pointerof(overlapped)), WinError.value}
            end
          {% else %}
            # poll at regular intervals (no unlock event)
            sleep 100.milliseconds
            {LibC.LockFileEx(windows_handle, flags | LibC::LOCKFILE_FAIL_IMMEDIATELY, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, pointerof(overlapped)), WinError.value}
          {% end %}
      end
    end
  end

  private def system_unlock : Nil
    if !system_blocking?
      IOCP.simple_overlapped_operation(Crystal::EventLoop.current.iocp_handle, self, "UnlockFileEx") do |operation|
        LibC.UnlockFileEx(windows_handle, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, operation)
      end
    else
      overlapped = LibC::OVERLAPPED.new
      ret = LibC.UnlockFileEx(windows_handle, 0, 0xFFFF_FFFF, 0xFFFF_FFFF, pointerof(overlapped))
      raise IO::Error.from_winerror("UnlockFileEx", target: self) if ret == 0
    end
  end

  private def system_fsync(flush_metadata = true) : Nil
    if LibC.FlushFileBuffers(windows_handle) == 0
      raise IO::Error.from_winerror("Error syncing file", target: self)
    end
  end

  private PIPE_BUFFER_SIZE = 8192

  def self.system_pipe(read_blocking, write_blocking)
    pipe_name = ::Path.windows(::File.tempname("crystal", nil, dir: %q(\\.\pipe))).normalize.to_s
    pipe_mode = 0 # PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT

    w_pipe_flags = LibC::PIPE_ACCESS_OUTBOUND | LibC::FILE_FLAG_FIRST_PIPE_INSTANCE
    w_pipe_flags |= LibC::FILE_FLAG_OVERLAPPED unless write_blocking
    w_pipe = LibC.CreateNamedPipeA(pipe_name, w_pipe_flags, pipe_mode, 1, PIPE_BUFFER_SIZE, PIPE_BUFFER_SIZE, 0, nil)
    raise IO::Error.from_winerror("CreateNamedPipeA") if w_pipe == LibC::INVALID_HANDLE_VALUE

    r_pipe_flags = LibC::FILE_FLAG_NO_BUFFERING
    r_pipe_flags |= LibC::FILE_FLAG_OVERLAPPED unless read_blocking
    r_pipe = LibC.CreateFileW(System.to_wstr(pipe_name), LibC::GENERIC_READ | LibC::FILE_WRITE_ATTRIBUTES, 0, nil, LibC::OPEN_EXISTING, r_pipe_flags, nil)
    raise IO::Error.from_winerror("CreateFileW") if r_pipe == LibC::INVALID_HANDLE_VALUE

    {r_pipe.address, w_pipe.address}
  end

  def self.from_stdio(fd)
    handle = case fd
             when 0 then LibC.GetStdHandle(LibC::STD_INPUT_HANDLE)
             when 1 then LibC.GetStdHandle(LibC::STD_OUTPUT_HANDLE)
             when 2 then LibC.GetStdHandle(LibC::STD_ERROR_HANDLE)
             else        LibC::INVALID_HANDLE_VALUE
             end

    console_handle = false
    if handle != LibC::INVALID_HANDLE_VALUE
      # TODO: use `out old_mode` after implementing interpreter out closured var
      old_mode = uninitialized LibC::DWORD
      if LibC.GetConsoleMode(handle, pointerof(old_mode)) != 0
        console_handle = true
        if fd == 1 || fd == 2 # STDOUT or STDERR
          if LibC.SetConsoleMode(handle, old_mode | LibC::ENABLE_VIRTUAL_TERMINAL_PROCESSING) != 0
            at_exit { LibC.SetConsoleMode(handle, old_mode) }
          end
        end
      end
    end

    # `blocking` must be set to `true` because the underlying handles never
    # support overlapped I/O; instead, `#emulated_blocking?` should return
    # `false` for `STDIN` as it uses a separate thread
    io = IO::FileDescriptor.new(handle: handle.address, blocking: true)

    # Set sync or flush_on_newline as described in STDOUT and STDERR docs.
    # See https://crystal-lang.org/api/toplevel.html#STDERR
    if console_handle
      io.sync = true
    else
      io.flush_on_newline = true
    end
    io
  end

  private def system_echo(enable : Bool)
    system_console_mode(enable, LibC::ENABLE_ECHO_INPUT, 0)
  end

  private def system_echo(enable : Bool, & : ->)
    system_console_mode(enable, LibC::ENABLE_ECHO_INPUT, 0) { yield }
  end

  private def system_raw(enable : Bool)
    system_console_mode(enable, LibC::ENABLE_VIRTUAL_TERMINAL_INPUT, LibC::ENABLE_PROCESSED_INPUT | LibC::ENABLE_LINE_INPUT | LibC::ENABLE_ECHO_INPUT)
  end

  private def system_raw(enable : Bool, & : ->)
    system_console_mode(enable, LibC::ENABLE_VIRTUAL_TERMINAL_INPUT, LibC::ENABLE_PROCESSED_INPUT | LibC::ENABLE_LINE_INPUT | LibC::ENABLE_ECHO_INPUT) { yield }
  end

  @[AlwaysInline]
  private def system_console_mode(enable, on_mask, off_mask, old_mode = nil)
    windows_handle = self.windows_handle
    unless old_mode
      if LibC.GetConsoleMode(windows_handle, out mode) == 0
        raise IO::Error.from_winerror("GetConsoleMode")
      end
      old_mode = mode
    end

    old_on_bits = old_mode & on_mask
    old_off_bits = old_mode & off_mask
    if enable
      return if old_on_bits == on_mask && old_off_bits == 0
      new_mode = (old_mode | on_mask) & ~off_mask
    else
      return if old_on_bits == 0 && old_off_bits == off_mask
      new_mode = (old_mode | off_mask) & ~on_mask
    end

    if @fd_lock.reference { LibC.SetConsoleMode(windows_handle, new_mode) } == 0
      raise IO::Error.from_winerror("SetConsoleMode")
    end
  end

  @[AlwaysInline]
  private def system_console_mode(enable, on_mask, off_mask, &)
    windows_handle = self.windows_handle
    if LibC.GetConsoleMode(windows_handle, out old_mode) == 0
      raise IO::Error.from_winerror("GetConsoleMode")
    end

    begin
      system_console_mode(enable, on_mask, off_mask, old_mode)
      yield
    ensure
      @fd_lock.reference { LibC.SetConsoleMode(windows_handle, old_mode) }
    end
  end
end

private module ConsoleUtils
  # N UTF-16 code units correspond to no more than 3*N UTF-8 code units.
  # NOTE: For very large buffers, `ReadConsoleW` may fail.
  private BUFFER_SIZE = 10000
  @@utf8_buffer = Slice(UInt8).new(3 * BUFFER_SIZE)

  # `@@buffer` points to part of `@@utf8_buffer`.
  # It represents data that has not been read yet.
  @@buffer : Bytes = @@utf8_buffer[0, 0]

  # Remaining UTF-16 code unit.
  @@remaining_unit : UInt16?

  # Determines if *handle* is a console.
  def self.console?(handle : LibC::HANDLE) : Bool
    LibC.GetConsoleMode(handle, out _) != 0
  end

  # Reads to *slice* from the console specified by *handle*,
  # and return the actual number of bytes read.
  def self.read(handle : LibC::HANDLE, slice : Bytes) : Int32
    return 0 if slice.empty?
    fill_buffer(handle) if @@buffer.empty?

    bytes_read = {slice.size, @@buffer.size}.min
    @@buffer[0, bytes_read].copy_to(slice)
    @@buffer += bytes_read
    bytes_read
  end

  private def self.fill_buffer(handle : LibC::HANDLE) : Nil
    utf16_buffer = uninitialized UInt16[BUFFER_SIZE]
    remaining_unit = @@remaining_unit
    if remaining_unit
      utf16_buffer[0] = remaining_unit
      index = read_console(handle, utf16_buffer.to_slice + 1)
    else
      index = read_console(handle, utf16_buffer.to_slice) - 1
    end

    if index >= 0 && utf16_buffer[index] & 0xFC00 == 0xD800
      @@remaining_unit = utf16_buffer[index]
      index -= 1
    else
      @@remaining_unit = nil
    end
    return if index < 0

    appender = @@utf8_buffer.to_unsafe.appender
    String.each_utf16_char(utf16_buffer.to_slice[..index]) do |char|
      char.each_byte do |byte|
        appender << byte
      end
    end
    @@buffer = appender.to_slice
  end

  {% if !flag?(:without_mt) && !flag?(:preview_mt) || flag?(:execution_context) %}
    private def self.read_console(handle : LibC::HANDLE, slice : Slice(UInt16)) : Int32
      units_read = LibC::DWORD.zero

      ret, error = Fiber.syscall do
        {LibC.ReadConsoleW(handle, slice, slice.size, pointerof(units_read), nil), WinError.value}
      end
      raise IO::Error.from_os_error("ReadConsoleW", error) if ret == 0

      units_read.to_i32
    end
  {% else %}
    class ReadRequest
      getter handle : LibC::HANDLE
      getter slice : Slice(UInt16)

      getter iocp_handle : LibC::HANDLE
      getter completion_key : Crystal::System::IOCP::CompletionKey

      property units_read = LibC::DWORD.zero
      property error = WinError::ERROR_SUCCESS

      def initialize(@handle : LibC::HANDLE, @slice : Slice(UInt16))
        @iocp_handle = Crystal::EventLoop.current.iocp_handle
        @completion_key = Crystal::System::IOCP::CompletionKey.new(:read_console, ::Fiber.current)
      end
    end

    @@read_mtx = ::Thread::Mutex.new
    @@read_cv = ::Thread::ConditionVariable.new
    @@read_requests = Deque(ReadRequest).new
    @@read_thread = ::Thread.new { reader_loop }

    private def self.read_console(handle : LibC::HANDLE, slice : Slice(UInt16)) : Int32
      request = ReadRequest.new(handle, slice)

      @@read_mtx.synchronize do
        @@read_requests << request
        @@read_cv.signal
      end

      ::Fiber.suspend

      unless request.error == WinError::ERROR_SUCCESS
        raise IO::Error.from_os_error("ReadConsoleW", request.error)
      end

      request.units_read.to_i32!
    end

    private def self.reader_loop
      while true
        request = @@read_mtx.synchronize do
          loop do
            if entry = @@read_requests.shift?
              break entry
            end
            @@read_cv.wait(@@read_mtx)
          end
        end
        slice = request.slice

        if LibC.ReadConsoleW(request.handle, slice, slice.size, out units_read, nil) == 0
          request.error = WinError.value
        else
          request.units_read = units_read
        end

        # OPTIMIZE: after #17091 we can merely `request.fiber.enqueue` and drop
        # the IOCP handle and CompletionKey
        completion_key = request.completion_key.as(Void*).address
        ret = LibC.PostQueuedCompletionStatus(request.handle, 0, completion_key, nil)

        # can't recover: the fiber will never be resumed
        Crystal::System.panic("PostQueuedCompletionStatus", WinError.value) if ret == 0
      end
    end
  {% end %}
end

# Enable UTF-8 console I/O for the duration of program execution
if LibC.IsValidCodePage(LibC::CP_UTF8) != 0
  old_input_cp = LibC.GetConsoleCP
  if LibC.SetConsoleCP(LibC::CP_UTF8) != 0
    at_exit { LibC.SetConsoleCP(old_input_cp) }
  end

  old_output_cp = LibC.GetConsoleOutputCP
  if LibC.SetConsoleOutputCP(LibC::CP_UTF8) != 0
    at_exit { LibC.SetConsoleOutputCP(old_output_cp) }
  end
end
