# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_cabin_global_optspecs
    string join \n v/verbose q/quiet color= list Z= V/version h/help
end

function __fish_cabin_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_cabin_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_cabin_using_subcommand
    set -l cmd (__fish_cabin_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c cabin -n "__fish_cabin_needs_command" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_needs_command" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_needs_command" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_needs_command" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_needs_command" -l list -d 'List installed commands'
complete -c cabin -n "__fish_cabin_needs_command" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_needs_command" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "init" -d 'Create a new cabin package in an existing directory'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "new" -d 'Create a new cabin package'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "add" -d 'Add a dependency to a cabin.toml manifest file'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "remove" -d 'Remove a dependency from a cabin.toml manifest file'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "metadata" -d 'Output workspace metadata as JSON'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "build" -d 'Compile a local package and all of its dependencies'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "b" -d 'Compile a local package and all of its dependencies'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "check" -d 'Check a local package for errors'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "clean" -d 'Remove build outputs'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "run" -d 'Run a binary of the local package'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "r" -d 'Run a binary of the local package'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "test" -d 'Run the tests of a local package'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "t" -d 'Run the tests of a local package'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "resolve" -d 'Resolve versioned dependencies'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "update" -d 'Update dependencies as recorded in `cabin.lock`'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "fetch" -d 'Fetch registry dependencies into the artifact cache'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "vendor" -d 'Vendor external versioned dependencies locally'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "tree" -d 'Display the dependency tree'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "explain" -d 'Explain a loaded package, target, source, or feature'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "package" -d 'Assemble the local package into a distributable archive'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "publish" -d 'Publish a package to a registry'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "login" -d 'Log in to a registry through GitHub'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "logout" -d 'Log out of a registry'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "yank" -d 'Yank or un-yank a published version on a remote registry'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "fmt" -d 'Format codes using clang-format'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "tidy" -d 'Run clang-tidy'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "compgen" -d 'Generate shell completion scripts for the `cabin` CLI'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "mangen" -d 'Generate man pages for the `cabin` CLI'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "version" -d 'Show version information'
complete -c cabin -n "__fish_cabin_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cabin -n "__fish_cabin_using_subcommand init" -l name -d 'Package name.  Defaults to the current directory name' -r
complete -c cabin -n "__fish_cabin_using_subcommand init" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand init" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand init" -s b -l bin -d 'Use a binary (application) template [default]'
complete -c cabin -n "__fish_cabin_using_subcommand init" -s l -l lib -d 'Use a library template'
complete -c cabin -n "__fish_cabin_using_subcommand init" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand init" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand init" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand new" -l name -d 'Package name.  Defaults to the final component of `<PATH>`' -r
complete -c cabin -n "__fish_cabin_using_subcommand new" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand new" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand new" -s b -l bin -d 'Use a binary (application) template [default]'
complete -c cabin -n "__fish_cabin_using_subcommand new" -s l -l lib -d 'Use a library template'
complete -c cabin -n "__fish_cabin_using_subcommand new" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand new" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand new" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand new" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand add" -l path -d 'Add a local path dependency rooted at <PATH> (relative to the manifest being edited)' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand add" -l features -d 'Features to enable on the dependency.  Repeatable and/or comma-separated (`--features a,b`)' -r
complete -c cabin -n "__fish_cabin_using_subcommand add" -l manifest-path -d 'Path to the cabin.toml manifest.  Defaults to the manifest discovered from the current directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand add" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand add" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand add" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand add" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand add" -l dev -d 'Add the entry to `[dev-dependencies]` instead of `[dependencies]`'
complete -c cabin -n "__fish_cabin_using_subcommand add" -l no-default-features -d 'Disable the dependency\'s default features (`default-features = false`)'
complete -c cabin -n "__fish_cabin_using_subcommand add" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand add" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand add" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand add" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand add" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l manifest-path -d 'Path to the cabin.toml manifest.  Defaults to the manifest discovered from the current directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l dev -d 'Remove from `[dev-dependencies]` instead of `[dependencies]`'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand remove" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l manifest-path -d 'Path to the cabin.toml manifest.  May be a single-package manifest or a workspace root' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l features -d 'Enable named features.  May be repeated and/or comma-separated' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l format -d 'Output format. `human` is a readable summary; `json` produces a machine-parseable document.  Defaults to `json` for back-compat with scripts that pipe the metadata output into `jq`' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l profile -d 'Profile to evaluate for the metadata view.  Defaults to the config `build.profile`, else `dev`.  The view always lists every available profile in the `profiles.available` array regardless of which one is selected' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l all-features -d 'Enable every declared feature'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l no-default-features -d 'Disable default features'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  Manifest `[patch]` tables and config `[patch]` / `[source-replacement]` declarations are ignored; ordinary `path = "..."` dependency edges and dependency declarations stay active'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -l offline -d 'Forbid network access. `cabin metadata` rejects an HTTP `--index-url` (or a `[registry] index-url` in the active config) when this flag is set so the metadata view stays fully local'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand metadata" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand build" -l build-dir -d 'Directory for build outputs (build.ninja, object files, binaries). Precedence: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand build" -l profile -d 'Select the build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev`.  Mutually exclusive with `--release`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand build" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`.  Static sparse HTTP serving of the file-registry layout is supported (`<url>/config.json`, `<url>/packages/<scope>/<name>.json`; a bare local name reads `<url>/packages/<name>.json`)' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand build" -l features -d 'Enable named features.  May be passed multiple times; values may also be comma-separated (`--features simd,ssl`).  The selection applies to the root package being built' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand build" -s j -l jobs -d 'Number of parallel jobs to use for building' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand build" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand build" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l locked -d 'Require an existing, current `cabin.lock`.  Resolution is not allowed to choose any version that differs from the lockfile'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects: The lockfile must not change and the artifact cache will not be populated.  Already-cached artifacts may be reused'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed artifact to be available from a local index (`--index-path`) or already in the artifact cache.  Combine with `cabin vendor` to consume a self-contained vendor directory'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l all-features -d 'Enable every feature declared by the root package.  Combines with `--features` (the union is the same as `--all-features`) and overrides `--no-default-features`'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l no-default-features -d 'Disable the package\'s default features.  Without this flag, the names listed under `[features].default` are enabled'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand build" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand build" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand build" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand build" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand build" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand b" -l build-dir -d 'Directory for build outputs (build.ninja, object files, binaries). Precedence: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand b" -l profile -d 'Select the build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev`.  Mutually exclusive with `--release`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand b" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`.  Static sparse HTTP serving of the file-registry layout is supported (`<url>/config.json`, `<url>/packages/<scope>/<name>.json`; a bare local name reads `<url>/packages/<name>.json`)' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand b" -l features -d 'Enable named features.  May be passed multiple times; values may also be comma-separated (`--features simd,ssl`).  The selection applies to the root package being built' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand b" -s j -l jobs -d 'Number of parallel jobs to use for building' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand b" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand b" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l locked -d 'Require an existing, current `cabin.lock`.  Resolution is not allowed to choose any version that differs from the lockfile'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects: The lockfile must not change and the artifact cache will not be populated.  Already-cached artifacts may be reused'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed artifact to be available from a local index (`--index-path`) or already in the artifact cache.  Combine with `cabin vendor` to consume a self-contained vendor directory'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l all-features -d 'Enable every feature declared by the root package.  Combines with `--features` (the union is the same as `--all-features`) and overrides `--no-default-features`'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l no-default-features -d 'Disable the package\'s default features.  Without this flag, the names listed under `[features].default` are enabled'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand b" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand b" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand b" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand b" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand b" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand check" -l build-dir -d 'Directory for build outputs (build.ninja, object files, binaries). Precedence: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand check" -l profile -d 'Select the build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev`.  Mutually exclusive with `--release`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand check" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`.  Static sparse HTTP serving of the file-registry layout is supported (`<url>/config.json`, `<url>/packages/<scope>/<name>.json`; a bare local name reads `<url>/packages/<name>.json`)' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand check" -l features -d 'Enable named features.  May be passed multiple times; values may also be comma-separated (`--features simd,ssl`).  The selection applies to the root package being built' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand check" -s j -l jobs -d 'Number of parallel jobs to use for building' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand check" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand check" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l locked -d 'Require an existing, current `cabin.lock`.  Resolution is not allowed to choose any version that differs from the lockfile'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects: The lockfile must not change and the artifact cache will not be populated.  Already-cached artifacts may be reused'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed artifact to be available from a local index (`--index-path`) or already in the artifact cache.  Combine with `cabin vendor` to consume a self-contained vendor directory'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l all-features -d 'Enable every feature declared by the root package.  Combines with `--features` (the union is the same as `--all-features`) and overrides `--no-default-features`'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l no-default-features -d 'Disable the package\'s default features.  Without this flag, the names listed under `[features].default` are enabled'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand check" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand check" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand check" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand check" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand check" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l manifest-path -d 'Path to the cabin.toml manifest.  Same precedence rules as `cabin build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l build-dir -d 'Build output directory.  Same precedence rules as `cabin build`: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l profile -d 'Limit the clean to the named build profile.  Without this flag every known profile sub-tree is in scope' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l target -d 'Clean the outputs of `--target <TRIPLE>` builds, under `<build-dir>/.targets/<TRIPLE>/`, instead of the build machine\'s' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l max-age -d 'With `--gc`: remove outputs unused for more than DAYS active days (days on which a build used this build directory). Overrides `gc.max-age`' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l max-size -d 'With `--gc`: then remove the least recently used outputs until the rest fit in SIZE (for example `10GiB`).  Overrides `gc.max-size`' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l release -d 'Compatibility alias for `--profile release`.  Cannot be used together with `--profile`'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l dry-run -d 'Print the deletion plan without removing anything.  Output lists the paths that would be removed in deterministic order'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l gc -d 'Remove only the build outputs Cabin\'s usage records show unused under the `[gc]` retention policy, in every profile and target'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand clean" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand run" -l build-dir -d 'Build output directory.  Same precedence rules as `cabin build`: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand run" -l profile -d 'Build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l bin -d 'Build and run the named `executable` target' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l index-path -d 'Path to a directory containing the local JSON package index' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand run" -l index-url -d 'Sparse HTTP index URL to read package metadata from' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand run" -l features -d 'Enable named features' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand run" -s j -l jobs -d 'Number of parallel jobs to use for the build phase' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand run" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand run" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l locked -d 'Require an existing, current `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l offline -d 'Forbid network access'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l all-features -d 'Enable every declared feature'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l no-default-features -d 'Disable default features'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand run" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand run" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand run" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand run" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand r" -l build-dir -d 'Build output directory.  Same precedence rules as `cabin build`: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand r" -l profile -d 'Build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l bin -d 'Build and run the named `executable` target' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l index-path -d 'Path to a directory containing the local JSON package index' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand r" -l index-url -d 'Sparse HTTP index URL to read package metadata from' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand r" -l features -d 'Enable named features' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand r" -s j -l jobs -d 'Number of parallel jobs to use for the build phase' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand r" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand r" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l locked -d 'Require an existing, current `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l offline -d 'Forbid network access'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l all-features -d 'Enable every declared feature'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l no-default-features -d 'Disable default features'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand r" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand r" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand r" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand r" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand r" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l build-dir -d 'Directory for build outputs (build.ninja, object files, linked test executables).  Precedence: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l profile -d 'Build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev` - the same default as `cabin build` so test runs match the developer\'s working profile' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l index-path -d 'Path to a directory containing the local JSON package index.  Required when the test build closure has any versioned dependency and `--index-url` is not given' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l index-url -d 'Sparse HTTP index URL' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l features -d 'Enable named features for the selected packages' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l test -d 'Run only the named `test` target; may be repeated' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -s j -l jobs -d 'Number of parallel jobs to use for the build phase' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l test-jobs -d 'Number of test executables to run at once' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l test-timeout -d 'Kill a test executable still running after this many seconds and report it as timed out' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -l junit -d 'Write an XML report of the test run to this path, in the format CI services read as test results' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand test" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand test" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand test" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l locked -d 'Require an existing, current `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l offline -d 'Forbid network access.  Combine with `cabin vendor` to run `cabin test` against a self-contained local index'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l all-features -d 'Enable every feature declared by selected packages'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l no-default-features -d 'Disable each selected package\'s default features'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation'
complete -c cabin -n "__fish_cabin_using_subcommand test" -l allow-no-tests -d 'Exit successfully when the selected packages declare no `test` targets.  By default, an empty selection errors so CI does not silently pass when tests have not been declared yet'
complete -c cabin -n "__fish_cabin_using_subcommand test" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand test" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand test" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand test" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l build-dir -d 'Directory for build outputs (build.ninja, object files, linked test executables).  Precedence: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l profile -d 'Build profile (`dev`, `release`, or any custom profile declared in `[profile.<name>]`).  Defaults to the config `build.profile`, else `dev` - the same default as `cabin build` so test runs match the developer\'s working profile' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l index-path -d 'Path to a directory containing the local JSON package index.  Required when the test build closure has any versioned dependency and `--index-url` is not given' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l index-url -d 'Sparse HTTP index URL' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l features -d 'Enable named features for the selected packages' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l test -d 'Run only the named `test` target; may be repeated' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -s j -l jobs -d 'Number of parallel jobs to use for the build phase' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l test-jobs -d 'Number of test executables to run at once' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l test-timeout -d 'Kill a test executable still running after this many seconds and report it as timed out' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -l junit -d 'Write an XML report of the test run to this path, in the format CI services read as test results' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand t" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand t" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand t" -s r -l release -d 'Build with optimizations'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l locked -d 'Require an existing, current `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l offline -d 'Forbid network access.  Combine with `cabin vendor` to run `cabin test` against a self-contained local index'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l all-features -d 'Enable every feature declared by selected packages'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l no-default-features -d 'Disable each selected package\'s default features'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation'
complete -c cabin -n "__fish_cabin_using_subcommand t" -l allow-no-tests -d 'Exit successfully when the selected packages declare no `test` targets.  By default, an empty selection errors so CI does not silently pass when tests have not been declared yet'
complete -c cabin -n "__fish_cabin_using_subcommand t" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand t" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand t" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand t" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`' -r
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l format -d 'Output format. `human` is a readable summary; `json` produces a machine-parseable document.  Defaults to `human`' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l features -d 'Feature names to enable on selected root packages. Repeatable; values may also be comma-separated' -r
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l locked -d 'Require an existing, current `cabin.lock`.  Resolution is not allowed to choose any version that differs from the lockfile. Implies that `cabin.lock` will not be written'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l frozen -d 'Like `--locked`, but also rejects any state-writing side effects'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed input to be local or already cached'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l all-features -d 'Enable every declared feature on selected root packages. Combines with `--features` (the union is requested)'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l no-default-features -d 'Disable selected root packages\' `default` feature'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand resolve" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand update" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand update" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand update" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`' -r
complete -c cabin -n "__fish_cabin_using_subcommand update" -l package -d 'Update only the named **dependency** (and any of its transitive deps that must change to satisfy the new constraints).  Without this flag every locked package is re-resolved' -r
complete -c cabin -n "__fish_cabin_using_subcommand update" -l format -d 'Output format for the resulting resolution' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand update" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand update" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand update" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand update" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed input to be local or already cached'
complete -c cabin -n "__fish_cabin_using_subcommand update" -l workspace -d 'Operate on every workspace member, then apply `--exclude`'
complete -c cabin -n "__fish_cabin_using_subcommand update" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the Workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand update" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand update" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand update" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand update" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand update" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l index-path -d 'Path to a directory containing the local JSON package index. Overrides the `[registry]` config setting and the default registry.  Mutually exclusive with `--index-url`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l index-url -d 'Sparse HTTP index URL to read package metadata from. Mutually exclusive with `--index-path`' -r
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l format -d 'Output format. `human` is a readable summary; `json` produces a machine-parseable document.  Defaults to `human`' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l locked -d 'Require an existing, current `cabin.lock`.  Resolution is not allowed to choose any version that differs from the lockfile'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects. The lockfile is not written and the artifact cache will not be populated.  Already-cached artifacts may be reused'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url`, a `[registry] index-url` config setting, or the default registry) and expects every needed input to be local or already cached'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation.  See `docs/patch-overrides.md`'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand fetch" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l vendor-dir -d 'Output directory for the vendored file registry. Defaults to `vendor` next to the workspace root' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l index-path -d 'Path to a directory containing the local JSON package index.  Required when the manifest declares any versioned dependencies. `cabin vendor` reads per-package metadata directly off disk to build a byte-stable vendor directory, so the index source must be local' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l cache-dir -d 'Override the default artifact cache directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l features -d 'Enable named features for the selected packages' -r
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l locked -d 'Require an existing, current `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l frozen -d 'Like `--locked`, but also rejects state-writing side effects on the lockfile and the artifact cache.  The vendor directory is the explicit user-requested output of the command and is still written under `--frozen`'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l offline -d 'Forbid network access.  Cabin refuses to use an HTTP index URL (`--index-url` or a `[registry] index-url` config setting) and expects every needed artifact to already be available in the artifact cache'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l all-features -d 'Enable every declared feature on selected packages'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l no-default-features -d 'Disable each selected package\'s default features'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand vendor" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l format -d 'Output format. `human` is a Unicode-drawing tree (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l kind -d 'Restrict the walk to one dependency kind.  Defaults to every kind' -r -f -a "all\t'Walk every kind (default)'
normal\t'`dependencies` edges only'"
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l features -d 'Enable named features.  May be repeated and/or comma-separated' -r
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l all-features -d 'Enable every declared feature'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l no-default-features -d 'Disable default features'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -l no-patches -d 'Disable every active patch and source-replacement entry for this invocation, mirroring `cabin metadata --no-patches`'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand tree" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l manifest-path -d 'Path to the cabin.toml manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l cc -d 'Override the C compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CC` and `[toolchain].cc`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l cxx -d 'Override the C++ compiler.  Accepts a bare command name or a path.  Highest precedence - also overrides `CXX` and `[toolchain].cxx`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l ar -d 'Override the static-library archiver.  Accepts a bare command name or a path.  Highest precedence - also overrides `AR` and `[toolchain].ar`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l compiler-wrapper -d 'Select an executable that prefixes every C and C++ compile command. Accepts a command name or path; `none` disables it. Highest precedence - also overrides `CABIN_COMPILER_WRAPPER`, config `[build]`, and the manifest `[build] compiler-wrapper` declaration. Mutually exclusive with `--no-compiler-wrapper`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l target -d 'Build for the platform named by a target triple such as `aarch64-unknown-linux-gnu` instead of the build machine. `cfg(...)` conditions evaluate for that platform, outputs go under `<build-dir>/.targets/<TRIPLE>/`, and Clang compilers receive `--target=<TRIPLE>`.  See `docs/toolchains.md`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l sysroot -d 'Build against the headers and libraries under this directory: GCC and Clang receive `--sysroot=<DIR>`, or `-isysroot <DIR>` for an Apple target.  Overrides the config `[sysroot]` entry for `--target`.  See `docs/toolchains.md`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l features -d 'Enable named features.  May be repeated and/or comma-separated' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l no-compiler-wrapper -d 'Disable the compiler wrapper for this invocation, regardless of any environment variable or manifest declaration.  Equivalent to `--compiler-wrapper none` but shorter to type.  Mutually exclusive with `--compiler-wrapper`'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l all-features -d 'Enable every declared feature'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l no-default-features -d 'Disable default features'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "package" -d 'Explain why a package is selected and which selected root pulls it in'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "target" -d 'Explain a target\'s owning package, kind, deps, and language summary'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "source" -d 'Explain where a package\'s source bytes come from'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "feature" -d 'Explain a feature\'s enablement on the named package'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "build-config" -d 'Explain the resolved build configuration for a package (profile, toolchain, flags, options, variants, condition trace, fingerprint)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and not __fish_seen_subcommand_from package target source feature build-config help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from package" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from target" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from source" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from feature" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -l format -d 'Output format. `human` is a concise summary (the default); `json` is a structured document for tooling' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -l profile -d 'Profile to evaluate, when the explanation depends on the build configuration (`build-config`).  Defaults to the config `build.profile`, else `dev`' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -l no-patches -d 'Disable every active patch / source-replacement entry'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from build-config" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "package" -d 'Explain why a package is selected and which selected root pulls it in'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "target" -d 'Explain a target\'s owning package, kind, deps, and language summary'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "source" -d 'Explain where a package\'s source bytes come from'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "feature" -d 'Explain a feature\'s enablement on the named package'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "build-config" -d 'Explain the resolved build configuration for a package (profile, toolchain, flags, options, variants, condition trace, fingerprint)'
complete -c cabin -n "__fish_cabin_using_subcommand explain; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cabin -n "__fish_cabin_using_subcommand package" -l manifest-path -d 'Path to the cabin.toml manifest.  Must point at a single package; pure-workspace roots are rejected unless the Workspace selects exactly one member with `--package`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand package" -l output-dir -d 'Directory for the generated archive and metadata' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand package" -l format -d 'Output format. `human` is a readable summary; `json` produces a machine-parseable document.  Defaults to `human`' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand package" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand package" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand package" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand package" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand package" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand package" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand package" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand package" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand package" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand package" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l manifest-path -d 'Path to the cabin.toml manifest.  Each must point at a single package; pure-workspace roots are rejected.  Repeat the flag to publish several packages in one invocation, in exactly the order given.  A remote batch stages and lint-checks everything before its first upload and authenticates once - which is what lets a trusted-publishing run exchange one OIDC token for its whole batch; the local `--registry-dir` flow writes each package in order.  Repeated paths are incompatible with the workspace selection flags' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l output-dir -d 'Directory for the dry-run\'s archive and metadata when `--registry-dir` is not given.  Defaults to `dist/`.  Mutually exclusive with `--registry-dir`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l registry-dir -d 'Local file-registry root to publish into.  Without `--dry-run`, the registry is mutated; with `--dry-run`, every pre-write check runs but the registry is left untouched' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l index-url -d 'Sparse HTTP index URL of the registry to publish to.  Falls back to the `[registry] index-url` config setting.  Requires `-Z remote-registry`; the staged archive and metadata are uploaded to the API origin the registry\'s `config.json` declares.  Combines with `--dry-run` (which stays entirely local); `--output-dir` then names the staging directory' -r
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l format -d 'Output format for the publish or dry-run report' -r -f -a "human\t''
json\t''"
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s p -l package -d 'Operate on the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member or appears twice in the workspace' -r
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l exclude -d 'Drop the named package from the selection.  Only valid in combination with `--workspace` or `--default-members`' -r
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l dry-run -d 'Run a publish dry-run only.  With `--registry-dir`, validates what would happen against the registry without mutating it. Without `--registry-dir`, runs the staging-only dry-run that writes the archive + metadata to `--output-dir`'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l new-revision -d 'Publish changed bytes for an already-published version as a new packaging revision of that version.  Without this flag, republishing a version with different bytes fails - published revisions are immutable, and an accidental respin usually means a forgotten version bump'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l retry-rate-limits -d 'Wait out registry rate limits (`429`) instead of failing fast: retry after the advertised delay, a few attempts, capped. Multi-package batches always pace (a serial batch charges the publish bucket per attempt); this flag extends the same pacing to a single-package publish - automation reruns hit the same drained bucket, where an interactive publish wants the immediate error'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l workspace -d 'Operate on every workspace member, then apply `--exclude`. Mutually exclusive with `--package` / `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -l default-members -d 'Operate on `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand publish" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand login" -l index-url -d 'Sparse HTTP index URL of the registry to log in to.  Falls back to the `[registry] index-url` config setting, then the default registry' -r
complete -c cabin -n "__fish_cabin_using_subcommand login" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand login" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand login" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand login" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand login" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand login" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand logout" -l index-url -d 'Sparse HTTP index URL of the registry to log out from.  Falls back to the `[registry] index-url` config setting, then the default registry' -r
complete -c cabin -n "__fish_cabin_using_subcommand logout" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand logout" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand logout" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand logout" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand logout" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand logout" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand yank" -l index-url -d 'Sparse HTTP index URL of the registry.  Falls back to the `[registry] index-url` config setting' -r
complete -c cabin -n "__fish_cabin_using_subcommand yank" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand yank" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand yank" -l undo -d 'Un-yank: clear the version\'s yanked flag instead of setting it'
complete -c cabin -n "__fish_cabin_using_subcommand yank" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand yank" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand yank" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand yank" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l manifest-path -d 'Path to the cabin.toml manifest.  Same precedence rules as `cabin build`: when omitted, Cabin walks upward from the current directory to find the nearest manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l build-dir -d 'Build output directory to exclude from source discovery. Same precedence rules as `cabin build`: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l exclude -d 'Exclude one file or directory from formatting.  May be repeated.  Paths are resolved against the current working directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s p -l package -d 'Format the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member' -r
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l check -d 'Verify formatting without rewriting any file.  Exits non-zero when at least one file would be reformatted'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l no-ignore-vcs -d 'Disable VCS ignore handling so files that are normally hidden by `.gitignore` are also formatted.  Cabin\'s built-in build / cache / vendor exclusions still apply'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l workspace -d 'Format every workspace member.  Cannot be combined with `--package` or `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -l default-members -d 'Format `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand fmt" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l manifest-path -d 'Path to the cabin.toml manifest.  Same precedence rules as `cabin build`: when omitted, Cabin walks upward from the current directory to find the nearest manifest' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l build-dir -d 'Build output directory for the generated compile database. Same precedence rules as `cabin build`: `--build-dir` > `CABIN_BUILD_DIR` > `[paths] build-dir` config setting > built-in default `build`' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l exclude -d 'Exclude one file or directory from the analysis.  May be repeated.  Paths are resolved against the current working directory' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s p -l package -d 'Analyze the named workspace package.  Repeat the flag to select multiple packages.  Errors when a name is not a workspace member' -r
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s j -l jobs -d 'Number of parallel `clang-tidy` instances to run.  Same precedence chain as `cabin build`: this flag wins over `CABIN_BUILD_JOBS`, then the `[build] jobs` config setting, then the backend\'s own default' -r
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l fix -d 'Apply the fixes clang-tidy suggests.  Off by default; Cabin never rewrites your sources unless this flag is passed explicitly'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l no-ignore-vcs -d 'Disable VCS ignore handling so files that are normally hidden by `.gitignore` are also analyzed.  Cabin\'s built-in build / cache / vendor exclusions still apply'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l workspace -d 'Analyze every workspace member.  Cannot be combined with `--package` or `--default-members`'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -l default-members -d 'Analyze `[workspace.default-members]`.  Errors when the workspace declares no default-members'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand tidy" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -l output-dir -d 'Directory to write the completion file(s) into.  Created if it does not already exist; existing files are overwritten. Without this flag a single shell\'s completion is written to stdout' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -l all -d 'Generate completions for every supported shell.  Requires `--output-dir`; multiple files cannot be written to stdout cleanly'
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand compgen" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -l output-dir -d 'Directory to write man pages into.  Created if it does not already exist; existing files are overwritten.  Without this flag the root `cabin(1)` man page is written to stdout' -r -F
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand mangen" -s h -l help -d 'Print help'
complete -c cabin -n "__fish_cabin_using_subcommand version" -l color -d 'Coloring: auto, always, never [default: auto]' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cabin -n "__fish_cabin_using_subcommand version" -s Z -d 'Enable an experimental feature (may be repeated)' -r
complete -c cabin -n "__fish_cabin_using_subcommand version" -s v -l verbose -d 'Use verbose output (-vv very verbose output)'
complete -c cabin -n "__fish_cabin_using_subcommand version" -s q -l quiet -d 'Do not print cabin log messages'
complete -c cabin -n "__fish_cabin_using_subcommand version" -s V -l version -d 'Print version info and exit'
complete -c cabin -n "__fish_cabin_using_subcommand version" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "init" -d 'Create a new cabin package in an existing directory'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "new" -d 'Create a new cabin package'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "add" -d 'Add a dependency to a cabin.toml manifest file'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "remove" -d 'Remove a dependency from a cabin.toml manifest file'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "metadata" -d 'Output workspace metadata as JSON'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "build" -d 'Compile a local package and all of its dependencies'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "check" -d 'Check a local package for errors'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "clean" -d 'Remove build outputs'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "run" -d 'Run a binary of the local package'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "test" -d 'Run the tests of a local package'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "resolve" -d 'Resolve versioned dependencies'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "update" -d 'Update dependencies as recorded in `cabin.lock`'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "fetch" -d 'Fetch registry dependencies into the artifact cache'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "vendor" -d 'Vendor external versioned dependencies locally'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "tree" -d 'Display the dependency tree'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "explain" -d 'Explain a loaded package, target, source, or feature'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "package" -d 'Assemble the local package into a distributable archive'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "publish" -d 'Publish a package to a registry'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "login" -d 'Log in to a registry through GitHub'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "logout" -d 'Log out of a registry'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "yank" -d 'Yank or un-yank a published version on a remote registry'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "fmt" -d 'Format codes using clang-format'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "tidy" -d 'Run clang-tidy'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "compgen" -d 'Generate shell completion scripts for the `cabin` CLI'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "mangen" -d 'Generate man pages for the `cabin` CLI'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "version" -d 'Show version information'
complete -c cabin -n "__fish_cabin_using_subcommand help; and not __fish_seen_subcommand_from init new add remove metadata build check clean run test resolve update fetch vendor tree explain package publish login logout yank fmt tidy compgen mangen version help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cabin -n "__fish_cabin_using_subcommand help; and __fish_seen_subcommand_from explain" -f -a "package" -d 'Explain why a package is selected and which selected root pulls it in'
complete -c cabin -n "__fish_cabin_using_subcommand help; and __fish_seen_subcommand_from explain" -f -a "target" -d 'Explain a target\'s owning package, kind, deps, and language summary'
complete -c cabin -n "__fish_cabin_using_subcommand help; and __fish_seen_subcommand_from explain" -f -a "source" -d 'Explain where a package\'s source bytes come from'
complete -c cabin -n "__fish_cabin_using_subcommand help; and __fish_seen_subcommand_from explain" -f -a "feature" -d 'Explain a feature\'s enablement on the named package'
complete -c cabin -n "__fish_cabin_using_subcommand help; and __fish_seen_subcommand_from explain" -f -a "build-config" -d 'Explain the resolved build configuration for a package (profile, toolchain, flags, options, variants, condition trace, fingerprint)'
