# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_tinymist_global_optspecs
	string join \n log-filter= h/help V/version
end

function __fish_tinymist_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_tinymist_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_tinymist_using_subcommand
	set -l cmd (__fish_tinymist_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c tinymist -n "__fish_tinymist_needs_command" -l log-filter -d 'Configure log filter of tinymist' -r
complete -c tinymist -n "__fish_tinymist_needs_command" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_needs_command" -s V -l version -d 'Print version'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "probe" -d 'Probe existence (Nop run)'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "lsp" -d 'Run language server'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "dap" -d 'Run debug adapter'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "trace-lsp" -d 'Run language server for tracing some typst program'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "query" -d 'Run language query'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "preview" -d 'Run preview server'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "compile" -d 'Run compile command like `typst-cli compile`'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "lint" -d 'Run Tinymist lint checks'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "package" -d 'Run package tools'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "completion" -d 'Generate completion script to stdout'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "generate-script" -d 'Generate build script for compilation'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "doc" -d 'Run documents'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "task" -d 'Run tasks'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "cov" -d 'Execute a document and collect coverage'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "test" -d 'Test a document and give summary'
complete -c tinymist -n "__fish_tinymist_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand probe" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand lsp" -l mirror -d 'Mirror the stdin to the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand lsp" -l replay -d 'Replay input from the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand lsp" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lsp" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand lsp" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand dap" -l mirror -d 'Mirror the stdin to the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand dap" -l replay -d 'Replay input from the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand dap" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand dap" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand dap" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l rpc-kind -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l mirror -d 'Mirror the stdin to the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l replay -d 'Replay input from the file' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l persist
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand trace-lsp" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "lsif" -d 'Get the lsif for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "scip" -d 'Get the SCIP index for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "packageDocs" -d 'Get the documentation for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "checkPackage" -d 'Check a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "tyckScope" -d 'Dump package scopes and type-checker results'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and not __fish_seen_subcommand_from lsif scip packageDocs checkPackage tyckScope help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l path -d 'The path of the package to request lsif for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l id -d 'The package of the package to request lsif for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -s o -l output -d 'The output path for the requested lsif' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from lsif" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l path -d 'The path of the package to request SCIP for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l id -d 'The package to request SCIP for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -s o -l output -d 'The output path for the requested SCIP protobuf' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l stats-output -d 'The output path for structured analysis statistics' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l index-summary-output -d 'The output path for structured SCIP index statistics' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from scip" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l path -d 'The path of the package to request docs for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l id -d 'The package of the package to request docs for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -s o -l output -d 'The output path for the requested docs' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from packageDocs" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l path -d 'The path of the package to request docs for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l id -d 'The package of the package to request docs for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -s o -l output -d 'The output path for the requested docs' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from checkPackage" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l path -d 'The path of the package to request tyck scopes for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l id -d 'The package to request tyck scopes for' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -s o -l output -d 'The output path for the requested tyck scope dump' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l max-type-chars -d 'Maximum characters kept for each dumped type string. Set to 0 to keep full strings' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from tyckScope" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "lsif" -d 'Get the lsif for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "scip" -d 'Get the SCIP index for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "packageDocs" -d 'Get the documentation for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "checkPackage" -d 'Check a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "tyckScope" -d 'Dump package scopes and type-checker results'
complete -c tinymist -n "__fish_tinymist_using_subcommand query; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l format -d 'Configure the preview output format' -r -f -a "paged\t'The current export target is for PDF, PNG, and SVG export'
html\t'The current export target is for HTML export'
bundle\t'The current export target is for bundle export'"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l preview-mode -d 'Configure the preview mode' -r -f -a "document\t'Would like to preview a regular document'
slide\t'Would like to preview slides'"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l page-title -d 'Set the preview page title' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l partial-rendering -d 'Only render visible part of the document' -r -f -a "true\t''
false\t''"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l invert-colors -d 'Configure the way to invert colors of the preview' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l refresh-style -d 'Used by lsp for controlling the preview refresh style' -r -f -a "on-save\t'Refresh preview on save'
on-type\t'Refresh preview on type'"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l task-id -d 'Used by lsp for identifying the task' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l data-plane-host -d 'Configure the data plane server address' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l control-plane-host -d 'Configure the control plane server address' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l host -d '(Deprecated) Configure (File) Host address for the preview server' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l not-primary -d 'Let it not be the primary instance'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l open -d 'Open the preview in the browser after compilation. If `--no-open` is set, this flag will be ignored'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l no-open -d 'Don\'t open the preview in the browser after compilation. If `--open` is set as well, this flag will win'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -l verbose -d 'Emit INFO level logging. The default is WARN'
complete -c tinymist -n "__fish_tinymist_using_subcommand preview" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l name -d 'Give a task name to the document' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l root -d 'Configure the project root (for absolute paths). If the path is relative, it will be resolved relative to the current working directory (PWD)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l when -d 'Configure when to run the task' -r -f -a "never\t'Never watch to run task'
onSave\t'Run task on saving the document, i.e. on `textDocument/didSave` events'
onType\t'Run task on typing, i.e. on `textDocument/didChange` events'
onDocumentHasTitle\t'*DEPRECATED* Run task when a document has a title and on saved, which is useful to filter out template files'
script\t'Checks by running a typst script'"
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -s f -l format -d 'Specify the format of the output file, inferred from the extension by default' -r -f -a "pdf\t'Export to PDF'
png\t'Export to PNG'
svg\t'Export to SVG'
html\t'Export to HTML'
bundle\t'Export to Bundle'"
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l pages -d 'Specify which pages to export. When unspecified, all pages are exported' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l lockfile -d 'Specify the path to the lock file. If the path is set, the lockfile will be saved (--save-lock)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -l save-lock -d 'Save the compilation arguments to the lock file. If `--lockfile` is not set, the lock file will be saved in the cwd'
complete -c tinymist -n "__fish_tinymist_using_subcommand compile" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l diagnostic-format -d 'Configure how diagnostics are printed' -r -f -a "human\t'Human-readable diagnostics'
short\t'Short Unix-style diagnostics'"
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand lint" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and not __fish_seen_subcommand_from docs help" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and not __fish_seen_subcommand_from docs help" -f -a "docs" -d 'Generate package API docs'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and not __fish_seen_subcommand_from docs help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l namespace -d 'Package namespace. Defaults to the namespace inferred from a local package layout, or `preview` for a plain package directory' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l watch -d 'Regenerate and export docs when package sources change'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from docs" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from help" -f -a "docs" -d 'Generate package API docs'
complete -c tinymist -n "__fish_tinymist_using_subcommand package; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand completion" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand generate-script" -s o -l output -d 'The path to the output script' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand generate-script" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and not __fish_seen_subcommand_from new configure help" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and not __fish_seen_subcommand_from new configure help" -f -a "new" -d 'Declare a document (project input)'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and not __fish_seen_subcommand_from new configure help" -f -a "configure" -d 'Configure document priority in workspace'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and not __fish_seen_subcommand_from new configure help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l name -d 'Give a task name to the document' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l root -d 'Configure the project root (for absolute paths). If the path is relative, it will be resolved relative to the current working directory (PWD)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from new" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from configure" -l name -d 'Give a task name to the document' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from configure" -l priority -d 'Set the unsigned priority of these task (lower numbers are higher priority)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from configure" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from help" -f -a "new" -d 'Declare a document (project input)'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from help" -f -a "configure" -d 'Configure document priority in workspace'
complete -c tinymist -n "__fish_tinymist_using_subcommand doc; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and not __fish_seen_subcommand_from preview help" -s h -l help -d 'Print help'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and not __fish_seen_subcommand_from preview help" -f -a "preview" -d 'Declare a preview task'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and not __fish_seen_subcommand_from preview help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l name -d 'Give a task name to the document' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l root -d 'Configure the project root (for absolute paths). If the path is relative, it will be resolved relative to the current working directory (PWD)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l task -d 'Name a task' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l when -d 'When to run the task' -r -f -a "never\t'Never watch to run task'
onSave\t'Run task on saving the document, i.e. on `textDocument/didSave` events'
onType\t'Run task on typing, i.e. on `textDocument/didChange` events'
onDocumentHasTitle\t'*DEPRECATED* Run task when a document has a title and on saved, which is useful to filter out template files'
script\t'Checks by running a typst script'"
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l format -d 'Configure the preview output format' -r -f -a "paged\t'The current export target is for PDF, PNG, and SVG export'
html\t'The current export target is for HTML export'
bundle\t'The current export target is for bundle export'"
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l preview-mode -d 'Configure the preview mode' -r -f -a "document\t'Would like to preview a regular document'
slide\t'Would like to preview slides'"
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l page-title -d 'Set the preview page title' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l partial-rendering -d 'Only render visible part of the document' -r -f -a "true\t''
false\t''"
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l invert-colors -d 'Configure the way to invert colors of the preview' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l refresh-style -d 'Used by lsp for controlling the preview refresh style' -r -f -a "on-save\t'Refresh preview on save'
on-type\t'Refresh preview on type'"
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from preview" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from help" -f -a "preview" -d 'Declare a preview task'
complete -c tinymist -n "__fish_tinymist_using_subcommand task; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand cov" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l root -d 'Configure the project root (for absolute paths)' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l font-path -d 'Add additional directories that are recursively searched for fonts' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l package-path -d 'Specify a custom path to local packages, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l package-cache-path -d 'Specify a custom path to package cache, defaults to system-dependent location' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l pdf-standard -d 'Specify the PDF standards that Typst will enforce conformance with' -r -f -a "1.4\t'PDF 1.4'
1.5\t'PDF 1.5'
1.6\t'PDF 1.6'
1.7\t'PDF 1.7'
2.0\t'PDF 2.0'
a-1b\t'PDF/A-1b'
a-1a\t'PDF/A-1a'
a-2b\t'PDF/A-2b'
a-2u\t'PDF/A-2u'
a-2a\t'PDF/A-2a'
a-3b\t'PDF/A-3b'
a-3u\t'PDF/A-3u'
a-3a\t'PDF/A-3a'
a-4\t'PDF/A-4'
a-4f\t'PDF/A-4f'
a-4e\t'PDF/A-4e'
ua-1\t'PDF/UA-1'"
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l ppi -d 'Specify the PPI (pixels per inch) to use for PNG export' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l features -d 'Enable in-development features that may be changed or removed at any time' -r -f -a "html\t'The HTML feature'
a11y-extras\t'The A11yExtras feature'
bundle\t'The bundle export feature'"
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l input -d 'Add a string key-value pair visible through `sys.inputs`' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l creation-timestamp -d 'Configure the document\'s creation date formatted as a UNIX timestamp (in seconds)' -r
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l cert -d 'Specify the path to CA certificate file for network access, especially for downloading typst packages' -r -F
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l print-coverage -d 'Style of printing coverage' -r -f -a "never\t'Don\'t print the coverage'
short\t'Prints the coverage in a short format'
full\t'Prints the coverage in a full format'"
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l pretty -d 'Whether to pretty-print HTML snapshots' -r -f -a "true\t''
false\t''"
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l ignore-system-fonts -d 'Ensure system fonts won\'t be searched, unless explicitly included via `--font-path`'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l no-pdf-tags -d 'By default, even when not producing a `PDF/UA-1` document, a tagged PDF document is written to provide a baseline of accessibility. In some circumstances (for example when trying to reduce the size of a document) it can be desirable to disable tagged PDF'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l update -d 'Whether to update the reference images'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l coverage -d 'Whether to collect coverage'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l watch -d 'Whether to run in watch mode'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l dashboard -d 'Whether to render the dashboard'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l no-dashboard -d 'Whether not to render the dashboard'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -l verbose -d 'Whether to log verbose information'
complete -c tinymist -n "__fish_tinymist_using_subcommand test" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "probe" -d 'Probe existence (Nop run)'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "lsp" -d 'Run language server'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "dap" -d 'Run debug adapter'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "trace-lsp" -d 'Run language server for tracing some typst program'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "query" -d 'Run language query'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "preview" -d 'Run preview server'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "compile" -d 'Run compile command like `typst-cli compile`'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "lint" -d 'Run Tinymist lint checks'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "package" -d 'Run package tools'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "completion" -d 'Generate completion script to stdout'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "generate-script" -d 'Generate build script for compilation'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "doc" -d 'Run documents'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "task" -d 'Run tasks'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "cov" -d 'Execute a document and collect coverage'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "test" -d 'Test a document and give summary'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and not __fish_seen_subcommand_from probe lsp dap trace-lsp query preview compile lint package completion generate-script doc task cov test help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from query" -f -a "lsif" -d 'Get the lsif for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from query" -f -a "scip" -d 'Get the SCIP index for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from query" -f -a "packageDocs" -d 'Get the documentation for a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from query" -f -a "checkPackage" -d 'Check a specific package'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from query" -f -a "tyckScope" -d 'Dump package scopes and type-checker results'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from package" -f -a "docs" -d 'Generate package API docs'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from doc" -f -a "new" -d 'Declare a document (project input)'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from doc" -f -a "configure" -d 'Configure document priority in workspace'
complete -c tinymist -n "__fish_tinymist_using_subcommand help; and __fish_seen_subcommand_from task" -f -a "preview" -d 'Declare a preview task'
